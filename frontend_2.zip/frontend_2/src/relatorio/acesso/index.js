import {useEffect, useState} from 'react';
import './styles.css';
import {Link} from 'react-router-dom';
import api from '../../services/api';

const Relatorio_acesso = () => {
   const [acesso,setCadastro] = useState([]); 
  useEffect(() => {
      api.get('acesso').then(response =>{
         setCadastro(response.data);
        })
   },[]);

return (
     
   <div id="acesso">
     <header>
     <Link to="/">
        Voltar para home
        </Link>
         <Link to="/acesso">
          Voltar para Acesso
          </Link>
    </header>
   
     <fieldset>
       <legend>Relatorio de Anuncios</legend>   
     </fieldset>     
     
   <table>
      <tr>
         <th>Id do anuncio</th>
         <th>nome do anúncio</th>
         <th>cliente</th>
         <th>data de início</th>
         <th>data de término</th>
         <th>investimento por dia</th>
      </tr>  
      {acesso.map(acesso =>(
        <tr key={acesso.id_anuncio}>
         <td>{acesso.id_anuncio}</td>            
         <td>{acesso.anuncio}</td>
         <td>{acesso.cliente}</td>
         <td>{acesso.data_ini}</td>
         <td>{acesso.data_fim}</td>
         <td>{Intl.NumberFormat('pt-BR',{style: 'currency',currency:'BRL'}).format(acesso.por_dia)}</td>
         </tr>
      ))}
    </table>
  </div>
    )   
};

export default Relatorio_acesso ;