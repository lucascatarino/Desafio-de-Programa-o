import {useEffect, useState} from 'react';
import './styles.css';
import {Link} from 'react-router-dom';
import api from '../../services/api';

const Relatorio_anuncio = () => {
   const [anuncio,setCadastro] = useState([]); 
  useEffect(() => {
      api.get('anuncio').then(response =>{
         setCadastro(response.data);
        })
   },[]);

return (
     
   <div id="anuncio">
     <header>
     <Link to="/">
        Voltar para home
        </Link>
         <Link to="/anuncio">
          Voltar para Anuncio
          </Link>
    </header>
   
     <fieldset>
       <legend>Relatorio de Anuncios</legend>   
     </fieldset>     
     
   <table>
      <tr>
         <th>Id so Anuncio</th>
         <th>valor total investido</th>
         <th>quantidade máxima de visualizações</th>
         <th>quantidade máxima de cliques</th>
         <th>quantidade máxima de compartilhamentos</th>
      </tr>  
      {anuncio.map(anuncio =>(
        <tr key={anuncio.id_anuncio}>
         <td>{anuncio.id_anuncio}</td>
         <td>{anuncio.valor_total_investido}</td>
         <td>{anuncio.quantidade_maxima}</td>
         <td>{anuncio.quantidade_cliques}</td>
         <td>{anuncio.quantidade_compartilhamentos}</td>
         <td>{anuncio.investimento_por_dia}</td>
         </tr>
      ))}
    </table>
  </div>
    )   
};

export default Relatorio_anuncio ;