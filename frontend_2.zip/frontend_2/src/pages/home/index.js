import React from 'react-icons/fi';
import './styles.css';
import {Link} from 'react-router-dom';

const Home = () => {
    return(
      <div id="page-home">
     
     <header>   
     <Link to="/acesso"> Ir para Acesso</Link>
     <Link to="/anuncio"> Ir para Anuncio</Link>
     </header>
     
      </div> 
    )
}

export default Home;