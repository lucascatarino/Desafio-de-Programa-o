import React,{useState} from 'react';
import './styles.css';
import {Link,useHistory} from 'react-router-dom';
import InputMask from "react-input-mask";
import api from '../../services/api';

const Acesso = () => {
  const history = useHistory();
  const [formData,setFromData] = useState({
    anuncio:'',
    cliente:'',
    data_ini:'', 
    data_fim:'',
    por_dia:'',
});

  /*armazenar informação*/
 function handleInputChange(event) {
    const { name, value } = event.target;
   setFromData({ ...formData,[name]: value});
}; 

async function handleSubmit(event){
   event.preventDefault();
   const {anuncio,cliente,data_ini,data_fim,por_dia} = formData;
    const data ={anuncio,cliente,data_ini,data_fim,por_dia};

   
 try {
  const response = await api.post('acesso',data)
     alert(response.data.mensagem);
     history.go(0);
 } catch (error) { 
   alert(error.response.data.error)
 }
};
 
return (
     <div id="page-acesso">
      <header>
      <Link to="/">
        Voltar para home
        </Link>
      <Link to="/Relatorio_acesso">
          Ir para Relatorio
        </Link>
     </header>
     <form onSubmit={handleSubmit}>
       <fieldset>
           <legend>
               Acessos
           </legend>
    
      <div className='field'> 
       <label htmlFor="name">Descreva o Anuncio</label>
       <input type="text" name="anuncio" id="anuncio" onChange={handleInputChange} required/>
       </div>    

     <div className='field'> 
       <label htmlFor="name">Nome do Anunciante</label>
       <input type="text" name="cliente" id="cliente" onChange={handleInputChange} required/>
       </div>  
       <div className='field-group'> 
      <div className='field'> 
       <label htmlFor="name">Inicio</label>
       <InputMask type="text" name="data_ini" id="data_ini" mask="99/99/9999" maskPlaceholder="DD/MM/YYYY" onChange={handleInputChange} required/>   
       </div>      
       
      <div className='field'> 
       <label htmlFor="name">Termino</label>
       <InputMask type="text" name="data_fim" id="data_fim" mask="99/99/9999" maskPlaceholder="DD/MM/YYYY" onChange={handleInputChange} required/>   
      </div>    

      <div className='field'> 
       <label htmlFor="name">Investimento Diario</label>
       <input type="text" name="por_dia" id="por_dia" onChange={handleInputChange} required/>
      </div>    
      </div>
     </fieldset>
     <button type="submit">Salvar</button>
     </form>
     
   </div>
 );
};

export default Acesso;