import React,{useState} from 'react';
import './styles.css';
import {Link,useHistory} from 'react-router-dom';
import api from '../../services/api';

const Anuncio = () => {
  const history = useHistory();
  const [formData,setFromData] = useState({
    valor_total_investido:'',
    quantidade_maxima:'',
    quantidade_cliques:'',
    quantidade_compartilhamentos:'',
    investimento_por_dia:''
});

  /*armazenar informação*/
 function handleInputChange(event) {
    const { name, value } = event.target;
   setFromData({ ...formData,[name]: value});
}; 

async function handleSubmit(event){
   event.preventDefault();
  const {valor_total_investido,quantidade_maxima,quantidade_cliques,quantidade_compartilhamentos,investimento_por_dia} = formData;
  const data ={valor_total_investido,quantidade_maxima,quantidade_cliques,quantidade_compartilhamentos,investimento_por_dia};

try {
  const response = await api.post('anuncio',data)
     alert(response.data.mensagem);
     history.go(0);
  }catch (error){ 
   alert(error.response.data.error)
  }
};
 
return (
     <div id="page-anuncio">
      <header>
      <Link to="/">
        Voltar para home
        </Link>
      <Link to="/Relatorio_anuncio">
          Ir para Relatorio
        </Link>
     </header>
     <form onSubmit={handleSubmit}>
       <fieldset>
           <legend>
                Anuncio
           </legend>
    
    <div className='field-group'> 
      <div className='field'> 
       <label htmlFor="name">Valor total investido</label>
       <input type="text" name="valor_total_investido" id="valor_total_investido" onChange={handleInputChange} required/>
       </div>    

     <div className='field'> 
       <label htmlFor="name">Quantidade máxima de visualizações</label>
       <input type="text" name="quantidade_maxima" id="quantidade_maxima" onChange={handleInputChange} required/>
       </div>  
       <div className='field-group'> 
      <div className='field'> 
       <label htmlFor="name">Quantidade máxima de cliques</label>
       <input type="text" name="quantidade_cliques" id="quantidade_cliques" onChange={handleInputChange} required/>
       </div>      
       
      <div className='field'> 
       <label htmlFor="name">Quantidade máxima de compartilhamentos</label>
       <input type="text" name="quantidade_compartilhamentos" id="quantidade_compartilhamentos" onChange={handleInputChange} required/>
      </div>    
      <div className='field'> 
       <label htmlFor="name">Investimento Diario</label>
       <input type="text" name="investimento_por_dia" id="investimento_por_dia" onChange={handleInputChange} required/>
      </div>    
    </div>   
  </div>
     </fieldset>
     <button type="submit">Salvar</button>
     </form>
     
   </div>
 );
};

export default Anuncio;