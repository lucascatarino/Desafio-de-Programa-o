import React from 'react';
import { Route, BrowserRouter,Switch,Redirect } from 'react-router-dom';
import Home from './pages/home';
import Acesso from './pages/acesso'; 
import Anuncio from './pages/anuncio'; 
import Relatorio_acesso from './relatorio/acesso'; 
import Relatorio_anuncio from './relatorio/anuncio'; 


const Routes = () => {
    return (
        
    <BrowserRouter>
     <Route component={Home} path="/" exact />
       <Route component={Acesso} path="/acesso" exact />
       <Route component={Relatorio_acesso} path="/Relatorio_acesso" exact />
       <Route component={Anuncio} path="/anuncio" exact />
       <Route component={Relatorio_anuncio} path="/Relatorio_anuncio" exact />
      </BrowserRouter>

    )
}

export default Routes;